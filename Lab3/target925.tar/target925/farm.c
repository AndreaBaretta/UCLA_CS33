/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_283(unsigned *p)
{
    *p = 2425378930U;
}

void setval_436(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_119()
{
    return 3347662911U;
}

unsigned addval_323(unsigned x)
{
    return x + 3284633944U;
}

unsigned getval_437()
{
    return 3277324977U;
}

unsigned addval_255(unsigned x)
{
    return x + 3100086360U;
}

void setval_440(unsigned *p)
{
    *p = 3347138802U;
}

unsigned getval_493()
{
    return 2425444460U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_334()
{
    return 3375944137U;
}

void setval_285(unsigned *p)
{
    *p = 3224421001U;
}

unsigned getval_192()
{
    return 3286272328U;
}

unsigned addval_174(unsigned x)
{
    return x + 3250751845U;
}

void setval_342(unsigned *p)
{
    *p = 3525366025U;
}

unsigned getval_142()
{
    return 3683959433U;
}

unsigned getval_153()
{
    return 2425671305U;
}

unsigned getval_272()
{
    return 2447411528U;
}

void setval_240(unsigned *p)
{
    *p = 2447411528U;
}

void setval_370(unsigned *p)
{
    *p = 3375943945U;
}

void setval_294(unsigned *p)
{
    *p = 3381969545U;
}

void setval_256(unsigned *p)
{
    *p = 3373846153U;
}

unsigned addval_181(unsigned x)
{
    return x + 3223372425U;
}

unsigned addval_211(unsigned x)
{
    return x + 2497743176U;
}

void setval_201(unsigned *p)
{
    *p = 3281047179U;
}

unsigned getval_213()
{
    return 3523792521U;
}

unsigned addval_307(unsigned x)
{
    return x + 3286272328U;
}

void setval_430(unsigned *p)
{
    *p = 46383752U;
}

unsigned getval_139()
{
    return 2464188744U;
}

void setval_315(unsigned *p)
{
    *p = 2425406089U;
}

unsigned getval_369()
{
    return 2425471625U;
}

unsigned addval_396(unsigned x)
{
    return x + 2429651443U;
}

unsigned addval_419(unsigned x)
{
    return x + 2430634248U;
}

unsigned addval_327(unsigned x)
{
    return x + 3376992649U;
}

unsigned getval_261()
{
    return 3223376297U;
}

unsigned addval_257(unsigned x)
{
    return x + 3531919753U;
}

unsigned getval_290()
{
    return 3232026249U;
}

unsigned getval_346()
{
    return 3526413961U;
}

unsigned addval_484(unsigned x)
{
    return x + 3230978441U;
}

unsigned getval_235()
{
    return 3286272456U;
}

unsigned getval_310()
{
    return 3281047049U;
}

unsigned getval_229()
{
    return 3531918985U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
